/**
ICA 2
Due Date: 2/8/19
Kasey Davis
**/


public class Pet {
	private String name;
	private String animal;
	private int age;

	public void setName(String name){
		this.name = name;
	}

	public void setAnimal(String animal){
		this.animal = animal;
	}

	public void setAge(int age){
		this.age = age;
	}

	public String getName(){
		return name;
	}

	public String getAnimal(){
		return animal;
	}

	public int getAge(){
		return age;
	}
}